export interface PendulumState {
  theta1: number;  // Angle of first arm
  theta2: number;  // Angle of second arm
  omega1: number;  // Angular velocity of first arm
  omega2: number;  // Angular velocity of second arm
}

export interface PhysicsParams {
  g: number;       // Gravity
  m1: number;      // Mass of first bob
  m2: number;      // Mass of second bob
  l1: number;      // Length of first arm
  l2: number;      // Length of second arm
  damping: number; // Friction/damping
}

export interface DataPoint {
  time: number;
  theta1: number;
  theta2: number;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}