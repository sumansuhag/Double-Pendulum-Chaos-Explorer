import { useState, useEffect } from 'react';
import { ChecklistItem } from '../types';

const STORAGE_KEY = 'db2-connection-checklist';

const initialItems: ChecklistItem[] = [
  {
    id: '1',
    title: 'Use Native IBM Db2 Connector',
    description: 'Select Get Data > IBM Db2 database (not ODBC) to enable DirectQuery mode',
    completed: false,
    category: 'setup',
  },
  {
    id: '2',
    title: 'Configure Server Address',
    description: 'Enter server as "server:port" format. Default port for Db2 for i is 446',
    completed: false,
    category: 'setup',
    warning: 'Do not use ODBC driver - it forces Import mode',
  },
  {
    id: '3',
    title: 'Select DirectQuery Mode',
    description: 'Explicitly choose DirectQuery during connection setup (not Import)',
    completed: false,
    category: 'setup',
  },
  {
    id: '4',
    title: 'Use Microsoft .NET Framework Driver',
    description: 'Select Microsoft .NET Framework driver version 4.5+, not IBM ODBC driver',
    completed: false,
    category: 'setup',
    warning: 'IBM ODBC driver causes licensing errors',
  },
  {
    id: '5',
    title: 'Avoid SQL Statements in Advanced Options',
    description: 'SQL statements are disabled in DirectQuery mode - skip this field',
    completed: false,
    category: 'advanced',
  },
  {
    id: '6',
    title: 'Enable Encryption if Required',
    description: 'Check encrypted connection option if your Db2 server requires SSL',
    completed: false,
    category: 'advanced',
  },
  {
    id: '7',
    title: 'Test with Basic Authentication',
    description: 'Use your IBM i credentials with basic authentication for initial testing',
    completed: false,
    category: 'advanced',
  },
  {
    id: '8',
    title: 'Update Power BI Desktop',
    description: 'Ensure you have the latest Power BI Desktop version for compatibility fixes',
    completed: false,
    category: 'advanced',
  },
  {
    id: '9',
    title: 'Install On-Premises Data Gateway',
    description: 'Install gateway on a machine with Db2 client access for Service refreshes',
    completed: false,
    category: 'gateway',
  },
  {
    id: '10',
    title: 'Configure Gateway Connection Mapping',
    description: 'Map identical connection details (server, database, credentials) in gateway',
    completed: false,
    category: 'gateway',
    warning: 'Connection mismatches will block DirectQuery',
  },
];

export const useChecklist = () => {
  const [items, setItems] = useState<ChecklistItem[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      setItems(JSON.parse(stored));
    } else {
      setItems(initialItems);
    }
  }, []);

  useEffect(() => {
    if (items.length > 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    }
  }, [items]);

  const toggleItem = (id: string) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const resetChecklist = () => {
    setItems(initialItems);
  };

  const getProgress = () => {
    const completed = items.filter(item => item.completed).length;
    return Math.round((completed / items.length) * 100);
  };

  const getItemsByCategory = (category: ChecklistItem['category']) => {
    return items.filter(item => item.category === category);
  };

  return {
    items,
    toggleItem,
    resetChecklist,
    getProgress,
    getItemsByCategory,
  };
};