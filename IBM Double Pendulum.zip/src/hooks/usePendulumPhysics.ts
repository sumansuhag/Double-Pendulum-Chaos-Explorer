import { useState, useRef, useCallback } from 'react';
import { PendulumState, PhysicsParams, DataPoint } from '../types';

const DEFAULT_PARAMS: PhysicsParams = {
  g: 9.81,
  m1: 1.0,
  m2: 1.0,
  l1: 1.0,
  l2: 1.0,
  damping: 0.0,
};

const INITIAL_STATE: PendulumState = {
  theta1: Math.PI / 2,
  theta2: Math.PI / 2,
  omega1: 0,
  omega2: 0,
};

export const usePendulumPhysics = () => {
  const [state, setState] = useState<PendulumState>(INITIAL_STATE);
  const [params, setParams] = useState<PhysicsParams>(DEFAULT_PARAMS);
  const [isRunning, setIsRunning] = useState(false);
  const [history, setHistory] = useState<DataPoint[]>([]);
  const [time, setTime] = useState(0);
  
  const animationRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);

  const calculateAccelerations = useCallback((s: PendulumState, p: PhysicsParams) => {
    const { theta1, theta2, omega1, omega2 } = s;
    const { g, m1, m2, l1, l2 } = p;

    const delta = theta1 - theta2;
    const den1 = (m1 + m2) * l1 - m2 * l1 * Math.cos(delta) * Math.cos(delta);
    const den2 = (l2 / l1) * den1;

    const num1 = m2 * l1 * omega1 * omega1 * Math.sin(delta) * Math.cos(delta);
    const num2 = m2 * g * Math.sin(theta2) * Math.cos(delta);
    const num3 = m2 * l2 * omega2 * omega2 * Math.sin(delta);
    const num4 = (m1 + m2) * g * Math.sin(theta1);

    const alpha1 = (num1 + num2 + num3 - num4) / den1;

    const num5 = -m2 * l2 * omega2 * omega2 * Math.sin(delta) * Math.cos(delta);
    const num6 = (m1 + m2) * g * Math.sin(theta1) * Math.cos(delta);
    const num7 = -(m1 + m2) * l1 * omega1 * omega1 * Math.sin(delta);
    const num8 = -(m1 + m2) * g * Math.sin(theta2);

    const alpha2 = (num5 + num6 + num7 + num8) / den2;

    return { alpha1, alpha2 };
  }, []);

  const step = useCallback((dt: number) => {
    setState(prevState => {
      let { theta1, theta2, omega1, omega2 } = prevState;
      
      // Runge-Kutta 4th order integration for better stability
      const k1 = calculateAccelerations({ theta1, theta2, omega1, omega2 }, params);
      
      const k2 = calculateAccelerations(
        {
          theta1: theta1 + omega1 * dt * 0.5,
          theta2: theta2 + omega2 * dt * 0.5,
          omega1: omega1 + k1.alpha1 * dt * 0.5,
          omega2: omega2 + k1.alpha2 * dt * 0.5,
        },
        params
      );
      
      const k3 = calculateAccelerations(
        {
          theta1: theta1 + omega1 * dt * 0.5 + k1.alpha1 * dt * 0.25,
          theta2: theta2 + omega2 * dt * 0.5 + k1.alpha2 * dt * 0.25,
          omega1: omega1 + k2.alpha1 * dt * 0.5,
          omega2: omega2 + k2.alpha2 * dt * 0.5,
        },
        params
      );
      
      const k4 = calculateAccelerations(
        {
          theta1: theta1 + omega1 * dt + k3.alpha1 * dt * 0.5,
          theta2: theta2 + omega2 * dt + k3.alpha2 * dt * 0.5,
          omega1: omega1 + k3.alpha1 * dt,
          omega2: omega2 + k3.alpha2 * dt,
        },
        params
      );

      omega1 += (k1.alpha1 + 2 * k2.alpha1 + 2 * k3.alpha1 + k4.alpha1) * dt / 6;
      omega2 += (k1.alpha2 + 2 * k2.alpha2 + 2 * k3.alpha2 + k4.alpha2) * dt / 6;
      
      // Apply damping
      omega1 *= (1 - params.damping * dt);
      omega2 *= (1 - params.damping * dt);

      theta1 += omega1 * dt;
      theta2 += omega2 * dt;

      // Calculate Cartesian coordinates
      const x1 = params.l1 * Math.sin(theta1);
      const y1 = params.l1 * Math.cos(theta1);
      const x2 = x1 + params.l2 * Math.sin(theta2);
      const y2 = y1 + params.l2 * Math.cos(theta2);

      const newState = { theta1, theta2, omega1, omega2 };
      
      // Update history
      setHistory(prev => {
        const newPoint: DataPoint = {
          time: time + dt,
          theta1,
          theta2,
          x1,
          y1,
          x2,
          y2,
        };
        const updated = [...prev, newPoint];
        // Keep last 500 points to prevent memory issues
        return updated.slice(-500);
      });

      setTime(t => t + dt);
      
      return newState;
    });
  }, [params, calculateAccelerations, time]);

  const animate = useCallback((timestamp: number) => {
    if (!lastTimeRef.current) lastTimeRef.current = timestamp;
    const dt = Math.min((timestamp - lastTimeRef.current) / 1000, 0.05); // Cap dt
    lastTimeRef.current = timestamp;

    if (isRunning) {
      step(dt);
    }

    animationRef.current = requestAnimationFrame(animate);
  }, [isRunning, step]);

  const toggleSimulation = useCallback(() => {
    setIsRunning(prev => {
      const newState = !prev;
      if (newState && !animationRef.current) {
        lastTimeRef.current = 0;
        animationRef.current = requestAnimationFrame(animate);
      }
      return newState;
    });
  }, [animate]);

  const resetSimulation = useCallback(() => {
    setIsRunning(false);
    setState(INITIAL_STATE);
    setHistory([]);
    setTime(0);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = undefined;
    }
    lastTimeRef.current = 0;
  }, []);

  const perturb = useCallback(() => {
    setState(prev => ({
      ...prev,
      theta1: prev.theta1 + (Math.random() - 0.5) * 0.1, // Small perturbation
    }));
  }, []);

  const updateParams = useCallback((newParams: Partial<PhysicsParams>) => {
    setParams(prev => ({ ...prev, ...newParams }));
  }, []);

  return {
    state,
    params,
    history,
    isRunning,
    time,
    toggleSimulation,
    resetSimulation,
    perturb,
    updateParams,
  };
};