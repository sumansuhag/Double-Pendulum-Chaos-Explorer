import { useState, useEffect } from 'react';
import { Dataset, Cell } from '../types';

const STORAGE_KEY = 'data-clipboard-datasets';

const createEmptyDataset = (id: string, name: string): Dataset => ({
  id,
  name,
  columns: ['var1', 'var2', 'var3'],
  rows: Array.from({ length: 5 }, (_, i) => ({
    id: `${id}-row-${i}`,
    cells: [
      { value: '', type: 'string' },
      { value: '', type: 'string' },
      { value: '', type: 'string' },
    ],
  })),
});

export const useDatasets = () => {
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [activeDatasetId, setActiveDatasetId] = useState<string>('');

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      setDatasets(parsed);
      setActiveDatasetId(parsed[0]?.id || '');
    } else {
      const initial = [createEmptyDataset('ds-1', 'Dataset 1'), createEmptyDataset('ds-2', 'Dataset 2')];
      setDatasets(initial);
      setActiveDatasetId('ds-1');
    }
  }, []);

  useEffect(() => {
    if (datasets.length > 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(datasets));
    }
  }, [datasets]);

  const activeDataset = datasets.find(d => d.id === activeDatasetId);

  const addDataset = () => {
    const newId = `ds-${Date.now()}`;
    const newDataset = createEmptyDataset(newId, `Dataset ${datasets.length + 1}`);
    setDatasets([...datasets, newDataset]);
    setActiveDatasetId(newId);
  };

  const updateDataset = (id: string, updates: Partial<Dataset>) => {
    setDatasets(datasets.map(d => d.id === id ? { ...d, ...updates } : d));
  };

  const updateCell = (datasetId: string, rowId: string, colIndex: number, value: string) => {
    const type = isNaN(Number(value)) || value === '' ? 'string' : 'number';
    setDatasets(datasets.map(ds => {
      if (ds.id !== datasetId) return ds;
      return {
        ...ds,
        rows: ds.rows.map(row => {
          if (row.id !== rowId) return row;
          const newCells = [...row.cells];
          newCells[colIndex] = { value, type };
          return { ...row, cells: newCells };
        }),
      };
    }));
  };

  const addRow = (datasetId: string) => {
    setDatasets(datasets.map(ds => {
      if (ds.id !== datasetId) return ds;
      const newRow = {
        id: `${datasetId}-row-${Date.now()}`,
        cells: ds.columns.map(() => ({ value: '', type: 'string' as const })),
      };
      return { ...ds, rows: [...ds.rows, newRow] };
    }));
  };

  const addColumn = (datasetId: string) => {
    setDatasets(datasets.map(ds => {
      if (ds.id !== datasetId) return ds;
      const newColName = `var${ds.columns.length + 1}`;
      return {
        ...ds,
        columns: [...ds.columns, newColName],
        rows: ds.rows.map(row => ({
          ...row,
          cells: [...row.cells, { value: '', type: 'string' as const }],
        })),
      };
    }));
  };

  const deleteRow = (datasetId: string, rowId: string) => {
    setDatasets(datasets.map(ds => {
      if (ds.id !== datasetId) return ds;
      return { ...ds, rows: ds.rows.filter(r => r.id !== rowId) };
    }));
  };

  const deleteColumn = (datasetId: string, colIndex: number) => {
    setDatasets(datasets.map(ds => {
      if (ds.id !== datasetId) return ds;
      return {
        ...ds,
        columns: ds.columns.filter((_, i) => i !== colIndex),
        rows: ds.rows.map(row => ({
          ...row,
          cells: row.cells.filter((_, i) => i !== colIndex),
        })),
      };
    }));
  };

  const pasteData = (datasetId: string, startRow: number, startCol: number, cells: Cell[][]) => {
    setDatasets(datasets.map(ds => {
      if (ds.id !== datasetId) return ds;
      
      let newRows = [...ds.rows];
      
      cells.forEach((rowCells, rowIndex) => {
        const targetRowIndex = startRow + rowIndex;
        
        if (targetRowIndex >= newRows.length) {
          const newRow = {
            id: `${datasetId}-row-${Date.now()}-${rowIndex}`,
            cells: ds.columns.map(() => ({ value: '', type: 'string' as const })),
          };
          newRows.push(newRow);
        }
        
        const row = { ...newRows[targetRowIndex] };
        row.cells = [...row.cells];
        
        rowCells.forEach((cell, colIndex) => {
          const targetColIndex = startCol + colIndex;
          if (targetColIndex < ds.columns.length) {
            row.cells[targetColIndex] = cell;
          }
        });
        
        newRows[targetRowIndex] = row;
      });
      
      return { ...ds, rows: newRows };
    }));
  };

  return {
    datasets,
    activeDataset,
    activeDatasetId,
    setActiveDatasetId,
    addDataset,
    updateDataset,
    updateCell,
    addRow,
    addColumn,
    deleteRow,
    deleteColumn,
    pasteData,
  };
};