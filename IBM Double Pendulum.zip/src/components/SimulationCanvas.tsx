import { useEffect, useRef } from 'react';
import { PendulumState, PhysicsParams } from '../types';

interface SimulationCanvasProps {
  state: PendulumState;
  params: PhysicsParams;
  history: Array<{ x1: number; y1: number; x2: number; y2: number }>;
}

export const SimulationCanvas = ({ state, params, history }: SimulationCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;
    const scale = Math.min(width, height) / (params.l1 + params.l2 + 0.5) / 2;
    const centerX = width / 2;
    const centerY = height / 3;

    // Clear canvas
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = '#f1f5f9';
    ctx.lineWidth = 1;
    const gridSize = 50;
    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Calculate positions
    const x1 = centerX + params.l1 * Math.sin(state.theta1) * scale;
    const y1 = centerY + params.l1 * Math.cos(state.theta1) * scale;
    const x2 = x1 + params.l2 * Math.sin(state.theta2) * scale;
    const y2 = y1 + params.l2 * Math.cos(state.theta2) * scale;

    // Draw trail
    if (history.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(99, 102, 241, 0.3)';
      ctx.lineWidth = 2;
      for (let i = 0; i < history.length; i++) {
        const hx = centerX + history[i].x2 * scale;
        const hy = centerY + history[i].y2 * scale;
        if (i === 0) ctx.moveTo(hx, hy);
        else ctx.lineTo(hx, hy);
      }
      ctx.stroke();
    }

    // Draw arms
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(x1, y1);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    // Draw pivot
    ctx.beginPath();
    ctx.arc(centerX, centerY, 8, 0, Math.PI * 2);
    ctx.fillStyle = '#475569';
    ctx.fill();

    // Draw first bob
    ctx.beginPath();
    ctx.arc(x1, y1, 15, 0, Math.PI * 2);
    ctx.fillStyle = '#3b82f6';
    ctx.fill();
    ctx.strokeStyle = '#1d4ed8';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw second bob
    ctx.beginPath();
    ctx.arc(x2, y2, 15, 0, Math.PI * 2);
    ctx.fillStyle = '#f43f5e';
    ctx.fill();
    ctx.strokeStyle = '#be123c';
    ctx.lineWidth = 2;
    ctx.stroke();

  }, [state, params, history]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full rounded-lg border border-slate-200 bg-white"
    />
  );
};