import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { Play, Pause, RotateCcw, Zap } from 'lucide-react';
import { PhysicsParams } from '../types';

interface ControlPanelProps {
  params: PhysicsParams;
  isRunning: boolean;
  onToggle: () => void;
  onReset: () => void;
  onPerturb: () => void;
  onUpdateParams: (params: Partial<PhysicsParams>) => void;
}

export const ControlPanel = ({
  params,
  isRunning,
  onToggle,
  onReset,
  onPerturb,
  onUpdateParams,
}: ControlPanelProps) => {
  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <Button
          onClick={onToggle}
          className={isRunning ? 'bg-amber-500 hover:bg-amber-600' : 'bg-blue-600 hover:bg-blue-700'}
        >
          {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
          {isRunning ? 'Pause' : 'Start'}
        </Button>
        <Button onClick={onReset} variant="outline">
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </Button>
        <Button onClick={onPerturb} variant="outline" className="text-purple-600 border-purple-200 hover:bg-purple-50">
          <Zap className="w-4 h-4 mr-2" />
          Perturb
        </Button>
      </div>

      <div className="space-y-4 pt-4 border-t border-slate-200">
        <h3 className="font-semibold text-slate-800">Physical Parameters</h3>
        
        <div className="space-y-2">
          <Label className="text-sm text-slate-600">Gravity (g): {params.g.toFixed(2)} m/s²</Label>
          <input
            type="range"
            min="1"
            max="20"
            step="0.1"
            value={params.g}
            onChange={(e) => onUpdateParams({ g: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-slate-600">Length 1 (l₁): {params.l1.toFixed(2)} m</Label>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={params.l1}
            onChange={(e) => onUpdateParams({ l1: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-slate-600">Length 2 (l₂): {params.l2.toFixed(2)} m</Label>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={params.l2}
            onChange={(e) => onUpdateParams({ l2: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-slate-600">Mass 1 (m₁): {params.m1.toFixed(2)} kg</Label>
          <input
            type="range"
            min="0.1"
            max="5"
            step="0.1"
            value={params.m1}
            onChange={(e) => onUpdateParams({ m1: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-slate-600">Mass 2 (m₂): {params.m2.toFixed(2)} kg</Label>
          <input
            type="range"
            min="0.1"
            max="5"
            step="0.1"
            value={params.m2}
            onChange={(e) => onUpdateParams({ m2: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-slate-600">Damping: {params.damping.toFixed(3)}</Label>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={params.damping}
            onChange={(e) => onUpdateParams({ damping: parseFloat(e.target.value) })}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>
      </div>
    </div>
  );
};