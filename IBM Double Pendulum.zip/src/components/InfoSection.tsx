import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Video, Activity, FileText, Target } from 'lucide-react';

export const InfoSection = () => {
  const cards = [
    {
      icon: Video,
      title: 'Dataset Content',
      description: 'High-frame-rate videos showing unpredictable motion under large-angle swings, with synchronized 2D/3D position tracks extracted via pattern matching.',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
    },
    {
      icon: Activity,
      title: 'Key Purpose',
      description: 'Benchmark for testing predictive models (LSTMs, Neural ODEs) on real chaotic systems, revealing limitations of purely simulated data.',
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
    },
    {
      icon: Target,
      title: 'Applications',
      description: 'Chaos theory validation, trajectory forecasting, and physics-informed AI training. Real data highlights unmodeled friction effects.',
      color: 'text-rose-600',
      bgColor: 'bg-rose-100',
    },
    {
      icon: FileText,
      title: 'License',
      description: 'Released under CDLA Sharing 1.0, enabling open research use and collaboration in nonlinear physics studies.',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-100',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {cards.map((card) => (
        <Card key={card.title} className="border-slate-200 bg-white">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-3 text-base">
              <div className={`p-2 rounded-lg ${card.bgColor}`}>
                <card.icon className={`w-5 h-5 ${card.color}`} />
              </div>
              {card.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription className="text-slate-600 leading-relaxed">
              {card.description}
            </CardDescription>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};