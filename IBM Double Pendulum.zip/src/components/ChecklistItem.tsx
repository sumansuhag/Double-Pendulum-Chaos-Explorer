import { Check, AlertTriangle } from 'lucide-react';
import { ChecklistItem as ChecklistItemType } from '../types';

interface ChecklistItemProps {
  item: ChecklistItemType;
  onToggle: () => void;
}

export const ChecklistItem = ({ item, onToggle }: ChecklistItemProps) => {
  return (
    <div className="group">
      <button
        onClick={onToggle}
        className={`
          w-full text-left p-4 rounded-lg border-2 transition-all duration-200
          ${item.completed 
            ? 'bg-green-50 border-green-300 hover:border-green-400' 
            : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-blue-50'
          }
        `}
      >
        <div className="flex items-start gap-3">
          <div className={`
            flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors
            ${item.completed 
              ? 'bg-green-500 border-green-500' 
              : 'border-slate-300 group-hover:border-blue-400'
            }
          `}>
            {item.completed && <Check className="w-4 h-4 text-white" />}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className={`
                font-medium transition-colors
                ${item.completed ? 'text-green-700 line-through' : 'text-slate-800'}
              `}>
                {item.title}
              </h3>
              {item.warning && (
                <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
              )}
            </div>
            <p className={`
              text-sm mt-1
              ${item.completed ? 'text-green-600' : 'text-slate-600'}
            `}>
              {item.description}
            </p>
            {item.warning && (
              <p className="text-xs text-amber-600 mt-2 font-medium">
                ⚠️ {item.warning}
              </p>
            )}
          </div>
        </div>
      </button>
    </div>
  );
};