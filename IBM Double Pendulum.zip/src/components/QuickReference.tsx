import { Database, Shield, RefreshCw, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

export const QuickReference = () => {
  const references = [
    {
      icon: Database,
      title: 'Native Connector',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      items: [
        'Get Data > IBM Db2 database',
        'Server format: server:port',
        'Default port: 446',
        'Select DirectQuery mode',
      ],
    },
    {
      icon: Shield,
      title: 'Driver Settings',
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      items: [
        'Use Microsoft .NET Framework 4.5+',
        'Avoid IBM ODBC driver',
        'Prevents licensing errors',
        'Enables DirectQuery',
      ],
    },
    {
      icon: RefreshCw,
      title: 'Gateway Setup',
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
      items: [
        'Install on machine with Db2 client',
        'Map identical connection details',
        'Same server, database, credentials',
        'Required for Service refresh',
      ],
    },
    {
      icon: AlertCircle,
      title: 'Common Issues',
      color: 'text-amber-600',
      bgColor: 'bg-amber-100',
      items: [
        'ODBC forces Import mode',
        'Connection mismatches block refresh',
        'Update Power BI Desktop',
        'SQL statements disabled in DirectQuery',
      ],
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {references.map((ref) => (
        <Card key={ref.title} className="border-slate-300">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <div className={`p-2 rounded-lg ${ref.bgColor}`}>
                <ref.icon className={`w-5 h-5 ${ref.color}`} />
              </div>
              {ref.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {ref.items.map((item, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-slate-600">
                  <span className="text-slate-400 mt-0.5">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};