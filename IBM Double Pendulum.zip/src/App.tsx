import { usePendulumPhysics } from './hooks/usePendulumPhysics';
import { SimulationCanvas } from './components/SimulationCanvas';
import { ControlPanel } from './components/ControlPanel';
import { TrajectoryChart } from './components/TrajectoryChart';
import { InfoSection } from './components/InfoSection';
import { Activity } from 'lucide-react';

function App() {
  const {
    state,
    params,
    history,
    isRunning,
    time,
    toggleSimulation,
    resetSimulation,
    perturb,
    updateParams,
  } = usePendulumPhysics();

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Double Pendulum Chaos Explorer</h1>
            <p className="text-sm text-slate-500">Interactive simulation of the IBM Chaotic Dataset dynamics</p>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-slate-800">Simulation View</h2>
                <div className="text-sm text-slate-500">
                  Time: <span className="font-mono">{time.toFixed(2)}s</span>
                </div>
              </div>
              <div className="aspect-video bg-slate-100 rounded-lg overflow-hidden">
                <SimulationCanvas state={state} params={params} history={history} />
              </div>
            </div>

            <TrajectoryChart history={history} />

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-medium text-blue-800 mb-2">Understanding Chaos</h3>
              <p className="text-sm text-blue-700">
                The double pendulum exhibits chaotic behavior—tiny changes in initial conditions lead to vastly different outcomes. 
                Click <strong>Perturb</strong> to introduce a small random change and watch how quickly the trajectory diverges from its original path.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
              <ControlPanel
                params={params}
                isRunning={isRunning}
                onToggle={toggleSimulation}
                onReset={resetSimulation}
                onPerturb={perturb}
                onUpdateParams={updateParams}
              />
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
              <h3 className="font-semibold text-slate-800 mb-4">Current State</h3>
              <div className="space-y-3 font-mono text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-500">θ₁:</span>
                  <span className="text-blue-600">{(state.theta1 / Math.PI).toFixed(3)}π</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">θ₂:</span>
                  <span className="text-rose-600">{(state.theta2 / Math.PI).toFixed(3)}π</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">ω₁:</span>
                  <span className="text-slate-700">{state.omega1.toFixed(3)} rad/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">ω₂:</span>
                  <span className="text-slate-700">{state.omega2.toFixed(3)} rad/s</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <section>
          <h2 className="text-lg font-semibold text-slate-800 mb-4">About the Dataset</h2>
          <InfoSection />
        </section>
      </main>

      <footer className="mt-12 border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-6 text-center text-sm text-slate-500">
          <p>Based on the Double Pendulum Chaotic Dataset by IBM</p>
          <p className="mt-1">Simulating real-world nonlinear physics for machine learning research</p>
        </div>
      </footer>
    </div>
  );
}

export default App;